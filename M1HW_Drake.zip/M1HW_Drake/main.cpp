// CSC 134
// M1HW1
// T Drake
// 1/17/19

#include <iostream>

using namespace std;

int main()
{
    //provide a brief introduction

    cout << "Hello, my name is Tommy Drake" << endl;
    cout << "I am currently getting an Associates in Science degree" << endl;
    cout << "I have " << 2 << " pets:" << endl;
    cout << "\ta boy dog" << endl;
    cout << "\ta girl dog" << endl;
    cout << endl;
    cout << "testing\t1\t2\t3" << endl;
    return 0;
}
